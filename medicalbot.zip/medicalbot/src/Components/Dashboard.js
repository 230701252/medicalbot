import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const navigate = useNavigate();
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div style={styles.container}>
      <button style={styles.logoutButton} onClick={() => navigate("/")}>Logout</button>
      <h1 style={styles.title}>Medical AI Assistant</h1>
      <h2 style={styles.subtitle}>
        Advanced AI Assistant For <span style={styles.gradientText}>Human Medical</span> Health
      </h2>
      <p style={styles.description}>
           I'm here to support you with any health-related queries you may have.
      </p>
      <img src="/images/aibot.webp" alt="AI Doctor" style={styles.image} />

      <div style={styles.buttonContainer}>
        <button style={styles.button}>AI Medical Chatbot</button>
        <button style={styles.button}>Mental Health Chatbot</button>
        <button style={styles.button}>Prescription Analysis</button>
        <button style={styles.button}>Feedbacks & Reviews</button>
      </div>
      
      <button
  style={isHovered ? { ...styles.logoutButton, ...styles.logoutButtonHover } : styles.logoutButton}
  onClick={() => navigate("/")}
  onMouseEnter={() => setIsHovered(true)}
  onMouseLeave={() => setIsHovered(false)}
>
  Logout
</button>

    </div>
  );
};

const styles = {
  container: {
    textAlign: "center",
    padding: "50px",
    backgroundColor: "#f7f9fc",
    minHeight: "100vh",
  },
  logoutButtonHover: {
    backgroundColor: "#d63031", // Darker red on hover
    transform: "scale(1.05)", // Slight enlargement effect
  },
  title: {
    fontSize: "40px",
    fontWeight: "bold",
    color: "rgb(61 101 179)",
  },
  subtitle: {
    fontSize: "24px",
    fontWeight: "bold",
    color: "#333",
  },
  gradientText: {
    background: "linear-gradient(to right, orange, red, blue)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
  },
  description: {
    fontSize: "16px",
    color: "#555",
    marginTop: "10px",
  },
  image: {
    width: "225px",
    marginTop: "20px",
  },
  buttonContainer: {
    marginTop: "20px",
  },
  button: {
    padding: "15px 25px",
    fontSize: "16px",
    fontWeight: "bold",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    margin: "10px",
    backgroundColor: "rgb(70, 130, 180)",
    color: "white",
    boxShadow: "0px 4px 6px rgba(0,0,0,0.2)",
  },
  logoutButton: {
    position: "absolute",
    top: "20px",
    right: "20px",
    padding: "10px 20px",
    fontSize: "14px",
    backgroundColor: "#ff4d4d",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
};

export default Dashboard;
