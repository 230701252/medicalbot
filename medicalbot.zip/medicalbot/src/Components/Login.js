// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";

// const Login = () => {
//   const navigate = useNavigate();
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [error, setError] = useState("");
//   const [isHovered, setIsHovered] = useState(false);

//   // Predefined valid users
//   const validUsers = [
//     { email: "hello@gmail.com", password: "123" },
//     { email: "welcome@gmail.com", password: "123" }
//   ];

//   const handleLogin = () => {
//     const userExists = validUsers.some(user => user.email === email && user.password === password);
    
//     if (userExists) {
//       navigate("/dashboard"); // Redirect to Dashboard on success
//     } else {
//       setError("Invalid email or password");
//     }
//   };

//   return (
//     <div style={styles.container}>
//       <div style={styles.card}>
//         <h2 style={styles.title}>Login</h2>
//         <div style={styles.inputContainer}>
//           <label style={styles.label}>Email</label>
//           <input
//             type="email"
//             value={email}
//             onChange={(e) => setEmail(e.target.value)}
//             style={styles.input}
//           />
//         </div>
//         <div style={styles.inputContainer}>
//           <label style={styles.label}>Password</label>
//           <input
//             type="password"
//             value={password}
//             onChange={(e) => setPassword(e.target.value)}
//             style={styles.input}
//           />
//         </div>
//         {error && <p style={styles.errorText}>{error}</p>} {/* Error message */}
//         <button
//           style={isHovered ? { ...styles.button, ...styles.buttonHover } : styles.button}
//           onClick={handleLogin}
//           onMouseEnter={() => setIsHovered(true)}
//           onMouseLeave={() => setIsHovered(false)}
//         >
//           Login
//         </button>
//       </div>
//     </div>
//   );
// };

// const styles = {
//   container: {
//     display: "flex",
//     justifyContent: "center",
//     alignItems: "center",
//     height: "100vh",
//     backgroundColor: "rgb(250 252 253)",
//   },
//   card: {
//     backgroundColor: "#4DD0E1",
//     padding: "30px",
//     borderRadius: "10px",
//     boxShadow: "0px 4px 10px rgba(0,0,0,0.2)",
//     textAlign: "center",
//     width: "350px",
//   },
//   title: {
//     fontSize: "24px",
//     fontWeight: "bold",
//     marginBottom: "20px",
//   },
//   inputContainer: {
//     textAlign: "left",
//     width: "100%",
//     marginBottom: "15px",
//   },
//   label: {
//     display: "block",
//     fontSize: "14px",
//     fontWeight: "bold",
//     marginBottom: "5px",
//   },
//   input: {
//     width: "100%",
//     padding: "8px",
//     border: "none",
//     borderBottom: "2px solid black",
//     outline: "none",
//     backgroundColor: "transparent",
//   },
//   errorText: {
//     color: "red",
//     fontSize: "12px",
//     marginTop: "5px",
//   },
//   button: {
//     width: "100%",
//     padding: "10px",
//     backgroundColor: "#4682B4",
//     color: "white",
//     fontWeight: "bold",
//     border: "none",
//     borderRadius: "5px",
//     cursor: "pointer",
//     marginTop: "15px",
//     transition: "background-color 0.3s ease, transform 0.2s ease",
//   },
//   buttonHover: {
//     backgroundColor: "#356897",
//     transform: "scale(1.05)",
//   },
// };

// export default Login;
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isHovered, setIsHovered] = useState(false);

  // Predefined valid users
  const validUsers = [
    { email: "helo@gmail.com", password: "123" },
    { email: "welcome@gmail.com", password: "123" }
  ];

  const handleLogin = () => {
    const userExists = validUsers.some(user => user.email === email && user.password === password);
    
    if (userExists) {
      navigate("/dashboard"); // Redirect to Dashboard on success
    } else {
      setError("Invalid email or password");
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.title}>LOGIN</h2>
        <div style={styles.inputContainer}>
          <label style={styles.label}>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={styles.input}
          />
        </div>
        <div style={styles.inputContainer}>
          <label style={styles.label}>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={styles.input}
          />
        </div>
        {error && <p style={styles.errorText}>{error}</p>} {/* Error message */}
        <button
          style={isHovered ? { ...styles.button, ...styles.buttonHover } : styles.button}
          onClick={handleLogin}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          Sign In
        </button>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100vh",
    backgroundColor: "#f4f6f8", // Light background color
  },
  card: {
    backgroundColor: "#87CEEB", 
    padding: "40px",
    borderRadius: "10px",
    boxShadow: "0px 4px 10px rgba(0,0,0,0.2)",
    textAlign: "center",
    width: "400px",
  },
  title: {
    fontSize: "24px",
    fontWeight: "bold",
    color: "black", // Changed to Black
    marginBottom: "20px",
  },
  inputContainer: {
    textAlign: "left",
    width: "100%",
    marginBottom: "15px",
  },
  label: {
    display: "block",
    fontSize: "14px",
    fontWeight: "bold",
    color: "black", // Changed to Black
    marginBottom: "5px",
  },
  input: {
    width: "100%",
    padding: "10px",
    border: "1px solid #ccc",
    borderRadius: "5px",
    outline: "none",
    backgroundColor: "#f9f9f9",
    color: "black", // Changed to Black
  },
  errorText: {
    color: "red",
    fontSize: "12px",
    marginTop: "5px",
  },
  button: {
    width: "100%",
    padding: "12px",
    backgroundColor: "#4682B4",
    color: "black", // Changed to Black
    fontWeight: "bold",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    marginTop: "15px",
    transition: "background-color 0.3s ease, transform 0.2s ease",
  },
  buttonHover: {
    backgroundColor: "#356897",
    transform: "scale(1.05)",
  },
};

export default Login;
