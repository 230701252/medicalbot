import React from "react";
import { useNavigate } from "react-router-dom";

const Welcome = () => {
  const navigate = useNavigate();

  return (
    <div className="flex justify-center items-center h-screen bg-white">
      <div className="max-w-6xl w-full flex bg-white shadow-lg rounded-lg overflow-hidden">
        
        {/* Left Side - Full Image */}
        <div className="w-1/2">
          <img
            src="images/aibot.webp" // Replace this with your image
            alt="Healthcare Chatbot"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Right Side - Text and Button */}
        <div className="w-1/2 p-10 flex flex-col justify-center">
          <h1 className="text-4xl font-bold text-black">CHATBOT</h1>
          <h2 className="text-2xl font-semibold text-black mt-2">
            HEALTHCARE USE
          </h2>
          <p className="text-black mt-4">
            Our AI-powered chatbot helps you with medical queries, hospital
            recommendations, and more. Start your healthcare journey now!
          </p>

          <button
            className="mt-6 px-6 py-3 bg-red-500 text-white font-bold rounded-lg shadow-md hover:bg-red-600 transition duration-300"
            onClick={() => navigate("/login")}
          >
            Get Started Now!
          </button>
        </div>
      </div>
    </div>
  );
};

export default Welcome;
